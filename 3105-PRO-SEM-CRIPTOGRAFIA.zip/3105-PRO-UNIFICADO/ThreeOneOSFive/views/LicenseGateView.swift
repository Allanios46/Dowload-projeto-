import SwiftUI

struct LicenseGateView<Content: View>: View {
    @StateObject private var client: LicenseClient
    @State private var key = ""
    @State private var showAdminAccess = false
    private let content: () -> Content

    init(baseURL: URL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!, @ViewBuilder content: @escaping () -> Content) {
        _client = StateObject(wrappedValue: LicenseClient(baseURL: baseURL))
        self.content = content
    }

    var body: some View {
        Group {
            if client.license?.valid == true {
                content().environmentObject(client)
            } else {
                Form {
                    Section {
                        Text("Allan IOS EXTERNAL")
                            .font(.title2.weight(.bold))
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    Section("Ativar 3105-PRO") {
                        SecureField("KEY", text: $key)
                        Button(client.isLoading ? "Consultando…" : "Ativar") {
                            Task { await client.activate(key: key) }
                        }.disabled(client.isLoading)
                        if !client.message.isEmpty { Text(client.message).foregroundStyle(.secondary) }
                    }
                    Section("Dispositivo") { Text(client.deviceID).font(.caption).textSelection(.enabled) }
                    Section {
                        Button {
                            showAdminAccess = true
                        } label: {
                            Label("Acesso ADMIN", systemImage: "lock.shield")
                        }
                    }
                }
            }
        }
        .sheet(isPresented: $showAdminAccess) {
            AdminAccessView()
        }
        .task {
            if let saved = client.savedKey { await client.activate(key: saved) }
        }
    }
}

struct FeatureRow: View {
    @EnvironmentObject private var license: LicenseClient
    let featureID: String
    let title: String
    let content: () -> AnyView

    var body: some View {
        if license.enabledFeatureIDs.contains(featureID) { content() }
        else { EmptyView() }
    }
}
