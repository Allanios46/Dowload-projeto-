import SwiftUI

struct AdminAccessView: View {
    @StateObject private var client: AdminClient
    @Environment(\.dismiss) private var dismiss

    init(baseURL: URL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!) {
        _client = StateObject(wrappedValue: AdminClient(baseURL: baseURL))
    }

    var body: some View {
        Group {
            if client.isAuthenticated {
                AdminDashboardView(client: client, dismiss: dismiss)
            } else {
                AdminLoginView(client: client, dismiss: dismiss)
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct AdminLoginView: View {
    @ObservedObject var client: AdminClient
    let dismiss: DismissAction
    @State private var key = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.02, green: 0.04, blue: 0.07), Color(red: 0.03, green: 0.10, blue: 0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            Circle().fill(Color.cyan.opacity(0.16)).frame(width: 280).blur(radius: 80).offset(x: 150, y: -320)
            Circle().fill(Color.blue.opacity(0.12)).frame(width: 240).blur(radius: 80).offset(x: -160, y: 330)

            ScrollView {
                VStack(spacing: 0) {
                    HStack {
                        Button { dismiss() } label: {
                            Image(systemName: "xmark").font(.system(size: 15, weight: .bold)).frame(width: 38, height: 38).background(.white.opacity(0.08), in: Circle())
                        }
                        Spacer()
                        Text("SECURE CONSOLE").font(.system(size: 10, weight: .bold, design: .rounded)).tracking(2).foregroundStyle(.cyan)
                    }
                    .foregroundStyle(.white.opacity(0.75))

                    VStack(spacing: 18) {
                        ZStack {
                            Circle().fill(.cyan.opacity(0.14)).frame(width: 86, height: 86)
                            Image(systemName: "lock.shield.fill").font(.system(size: 38, weight: .semibold)).foregroundStyle(.cyan)
                        }
                        Text("Allan IOS EXTERNAL").font(.system(size: 28, weight: .bold, design: .rounded)).foregroundStyle(.white)
                        Text("Painel ADMIN").font(.system(size: 15, weight: .medium, design: .rounded)).foregroundStyle(.cyan.opacity(0.9))
                        Text("Acesse o centro de controle para criar funções, clientes e KEYs de licença.")
                            .multilineTextAlignment(.center).font(.subheadline).foregroundStyle(.white.opacity(0.55)).padding(.horizontal, 20)
                    }
                    .padding(.top, 46)

                    VStack(alignment: .leading, spacing: 12) {
                        Text("KEY ADMIN").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.58))
                        SecureField("Digite sua chave privada", text: $key)
                            .focused($focused)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .padding(.horizontal, 16).frame(height: 54)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.12)))
                        Button {
                            Task { await client.login(key: key) }
                        } label: {
                            HStack {
                                if client.isLoading { ProgressView().tint(.black) }
                                Text(client.isLoading ? "Validando acesso…" : "Entrar no ADMIN").fontWeight(.bold)
                                Spacer()
                                Image(systemName: "arrow.right").fontWeight(.bold)
                            }
                            .padding(.horizontal, 18).frame(height: 54)
                            .foregroundStyle(.black).background(.cyan, in: RoundedRectangle(cornerRadius: 16))
                        }
                        .disabled(key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || client.isLoading)
                        if !client.message.isEmpty {
                            Text(client.message).font(.footnote).foregroundStyle(client.isAuthenticated ? .green : .orange)
                        }
                    }
                    .padding(20).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.10)))
                    .padding(.top, 34)

                    Label("A validação acontece no servidor. A KEY não fica gravada na IPA.", systemImage: "checkmark.shield")
                        .font(.caption).foregroundStyle(.white.opacity(0.42)).multilineTextAlignment(.center).padding(.top, 22)
                }
                .padding(.horizontal, 22).padding(.top, 16).padding(.bottom, 30)
            }
        }
        .onAppear { focused = true }
    }
}

private struct AdminDashboardView: View {
    @ObservedObject var client: AdminClient
    let dismiss: DismissAction
    @State private var selectedTab = 0
    @State private var showingFeature = false
    @State private var showingClient = false
    @State private var showingKey = false
    @State private var generatedKey: String?

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.025, green: 0.035, blue: 0.055).ignoresSafeArea()
                VStack(spacing: 0) {
                    Picker("Seção", selection: $selectedTab) {
                        Text("Resumo").tag(0)
                        Text("Funções").tag(1)
                        Text("KEYs").tag(2)
                        Text("Clientes").tag(3)
                    }
                    .pickerStyle(.segmented).padding()
                    ScrollView {
                        Group {
                            if selectedTab == 0 { adminOverview }
                            if selectedTab == 1 { featureList }
                            if selectedTab == 2 { keyList }
                            if selectedTab == 3 { clientList }
                        }
                        .padding(.horizontal).padding(.bottom, 28)
                    }
                }
            }
            .navigationTitle("ADMIN").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { dismiss() } label: { Image(systemName: "xmark") } }
                ToolbarItem(placement: .topBarTrailing) { Button { client.logout(); dismiss() } label: { Image(systemName: "rectangle.portrait.and.arrow.right") } }
            }
            .task { await client.refresh() }
            .sheet(isPresented: $showingFeature) { CreateFeatureSheet(client: client) }
            .sheet(isPresented: $showingClient) { CreateClientSheet(client: client) }
            .sheet(isPresented: $showingKey) { CreateKeySheet(client: client) { key in generatedKey = key } }
            .alert("KEY criada", isPresented: Binding(get: { generatedKey != nil }, set: { if !$0 { generatedKey = nil } })) {
                Button("Concluir", role: .cancel) { generatedKey = nil }
            } message: { Text(generatedKey ?? "") }
        }
    }

    private var adminOverview: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Tudo sob controle.").font(.largeTitle.bold()).foregroundStyle(.white)
            Text("Gerencie o acesso dos clientes diretamente pela IPA.").foregroundStyle(.white.opacity(0.55))
            HStack(spacing: 12) {
                MetricCard(title: "Funções", value: "\(client.snapshot?.features.count ?? 0)", color: .cyan)
                MetricCard(title: "KEYs", value: "\(client.snapshot?.keys.count ?? 0)", color: .purple)
            }
            Button { showingKey = true } label: { AdminActionLabel(title: "Gerar nova KEY", subtitle: "Liberar funções para um cliente", icon: "key.fill", color: .cyan) }
            Button { showingFeature = true } label: { AdminActionLabel(title: "Criar função", subtitle: "Adicionar uma função ao sistema", icon: "slider.horizontal.3", color: .purple) }
            Button { showingClient = true } label: { AdminActionLabel(title: "Cadastrar cliente", subtitle: "Organizar as licenças por cliente", icon: "person.badge.plus", color: .blue) }
        }
    }

    private var featureList: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Funções", button: "Nova função") { showingFeature = true }
            ForEach(client.snapshot?.features ?? []) { feature in
                HStack(spacing: 14) {
                    Image(systemName: feature.enabled ? "checkmark.circle.fill" : "circle").foregroundStyle(feature.enabled ? .green : .white.opacity(0.3))
                    VStack(alignment: .leading) { Text(feature.name).foregroundStyle(.white); Text(feature.slug).font(.caption.monospaced()).foregroundStyle(.cyan.opacity(0.7)); if let description = feature.description { Text(description).font(.caption).foregroundStyle(.white.opacity(0.45)) } }
                    Spacer()
                }.padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
            }
        }
    }

    private var keyList: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "KEYs de clientes", button: "Gerar KEY") { showingKey = true }
            ForEach(client.snapshot?.keys ?? []) { key in
                VStack(alignment: .leading, spacing: 6) { Text(key.label).font(.headline).foregroundStyle(.white); Text(key.client?.name ?? "Sem cliente").font(.subheadline).foregroundStyle(.white.opacity(0.55)); Text(key.status.uppercased()).font(.caption.bold()).foregroundStyle(key.status == "active" ? .green : .red) }
                    .frame(maxWidth: .infinity, alignment: .leading).padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
            }
        }
    }

    private var clientList: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Clientes", button: "Novo cliente") { showingClient = true }
            ForEach(client.snapshot?.clients ?? []) { item in
                HStack { Image(systemName: "person.crop.circle.fill").foregroundStyle(.blue); VStack(alignment: .leading) { Text(item.name).foregroundStyle(.white); Text(item.email ?? "Sem e-mail").font(.caption).foregroundStyle(.white.opacity(0.45)) }; Spacer(); Text(item.status == "active" ? "ATIVO" : "BLOQUEADO").font(.caption2.bold()).foregroundStyle(item.status == "active" ? .green : .red) }.padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
            }
        }
    }
}

private struct MetricCard: View { let title: String; let value: String; let color: Color; var body: some View { VStack(alignment: .leading, spacing: 8) { Text(title).font(.caption).foregroundStyle(.white.opacity(0.5)); Text(value).font(.title.bold()).foregroundStyle(color) }.frame(maxWidth: .infinity, alignment: .leading).padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16)) } }
private struct AdminActionLabel: View { let title: String; let subtitle: String; let icon: String; let color: Color; var body: some View { HStack(spacing: 14) { Image(systemName: icon).font(.title3).foregroundStyle(color).frame(width: 42, height: 42).background(color.opacity(0.13), in: RoundedRectangle(cornerRadius: 12)); VStack(alignment: .leading) { Text(title).font(.headline).foregroundStyle(.white); Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.5)) }; Spacer(); Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.4)) }.padding().background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16)) } }
private struct SectionHeader: View { let title: String; let button: String; let action: () -> Void; var body: some View { HStack { Text(title).font(.title2.bold()).foregroundStyle(.white); Spacer(); Button(button, action: action).font(.subheadline.bold()).foregroundStyle(.cyan) } } }

private struct CreateFeatureSheet: View { @ObservedObject var client: AdminClient; @Environment(\.dismiss) private var dismiss; @State private var slug = ""; @State private var name = ""; @State private var description = ""; var body: some View { NavigationStack { Form { TextField("Nome da função", text: $name); TextField("Identificador (ex.: patches-pro)", text: $slug); TextField("Descrição", text: $description) }.navigationTitle("Nova função").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Criar") { Task { if await client.createFeature(slug: slug, name: name, description: description) { dismiss() } } }.disabled(name.isEmpty || slug.isEmpty) } } } } }
private struct CreateClientSheet: View { @ObservedObject var client: AdminClient; @Environment(\.dismiss) private var dismiss; @State private var name = ""; @State private var email = ""; var body: some View { NavigationStack { Form { TextField("Nome do cliente", text: $name); TextField("E-mail (opcional)", text: $email).textInputAutocapitalization(.never).keyboardType(.emailAddress) }.navigationTitle("Novo cliente").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Adicionar") { Task { if await client.createClient(name: name, email: email) { dismiss() } } }.disabled(name.isEmpty) } } } } }
private struct CreateKeySheet: View { @ObservedObject var client: AdminClient; @Environment(\.dismiss) private var dismiss; let onCreated: (String) -> Void; @State private var label = ""; @State private var days = "30"; @State private var selected: Set<Int> = []; var body: some View { NavigationStack { Form { TextField("Nome da KEY", text: $label); TextField("Validade em dias", text: $days).keyboardType(.numberPad); Section("Funções liberadas") { ForEach(client.snapshot?.features ?? []) { feature in Toggle(feature.name, isOn: Binding(get: { selected.contains(feature.id) }, set: { enabled in if enabled { selected.insert(feature.id) } else { selected.remove(feature.id) } })) } } }.navigationTitle("Gerar KEY").toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Gerar") { Task { if let key = await client.createKey(label: label, days: Int(days) ?? 30, clientID: nil, featureIDs: Array(selected)) { onCreated(key); dismiss() } } }.disabled(label.isEmpty) } } } } }
