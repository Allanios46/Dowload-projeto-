import Foundation
import Combine
import Security

struct AdminFeature: Codable, Identifiable {
    let id: Int
    let slug: String
    let name: String
    let description: String?
    var enabled: Bool
}

struct AdminClientRecord: Codable, Identifiable {
    let id: Int
    let name: String
    let email: String?
    let status: String
}

struct AdminKeyRecord: Codable, Identifiable {
    let id: Int
    let label: String
    let status: String
    let expiresAt: String?
    let client: AdminClientRecord?
    let featureIds: [Int]
}

struct AdminSnapshot: Codable {
    let keys: [AdminKeyRecord]
    let features: [AdminFeature]
    let clients: [AdminClientRecord]
}

private struct AdminLoginResponse: Codable {
    let authenticated: Bool
    let token: String?
    let error: String?
}

private struct AdminMutationResponse: Codable {
    let success: Bool?
    let key: String?
    let expiresAt: String?
    let error: String?
}

@MainActor
final class AdminClient: ObservableObject {
    @Published private(set) var isAuthenticated = false
    @Published private(set) var snapshot: AdminSnapshot?
    @Published private(set) var isLoading = false
    @Published var message = ""

    private let baseURL: URL
    private let tokenKey = "3105.pro.admin.bearer"

    init(baseURL: URL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!) {
        self.baseURL = baseURL
        isAuthenticated = KeychainStore.read(tokenKey) != nil
    }

    func login(key: String) async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { message = "Digite a KEY ADMIN."; return }
        isLoading = true
        defer { isLoading = false }
        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("api/v1/admin/login"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(["key": value])
            let (data, response) = try await URLSession.shared.data(for: request)
            let result = try JSONDecoder().decode(AdminLoginResponse.self, from: data)
            guard (response as? HTTPURLResponse)?.statusCode == 200,
                  result.authenticated,
                  let token = result.token else {
                message = result.error ?? "KEY ADMIN recusada."
                return
            }
            KeychainStore.save(token, for: tokenKey)
            isAuthenticated = true
            message = "Acesso ADMIN autorizado."
            await refresh()
        } catch {
            message = "Não foi possível acessar o servidor: \(error.localizedDescription)"
        }
    }

    func logout() {
        KeychainStore.delete(tokenKey)
        isAuthenticated = false
        snapshot = nil
        message = "Sessão ADMIN encerrada."
    }

    func refresh() async {
        guard let token = KeychainStore.read(tokenKey) else {
            isAuthenticated = false
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("api/v1/admin/snapshot"))
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                if (response as? HTTPURLResponse)?.statusCode == 401 { logout() }
                message = "Não foi possível carregar os dados ADMIN."
                return
            }
            snapshot = try JSONDecoder().decode(AdminSnapshot.self, from: data)
        } catch {
            message = "Erro ao carregar o painel: \(error.localizedDescription)"
        }
    }

    func createFeature(slug: String, name: String, description: String) async -> Bool {
        let body: [String: String] = ["slug": slug, "name": name, "description": description]
        let success = await send(path: "api/v1/admin/features", method: "POST", body: body)
        if success { await refresh() }
        return success
    }

    func createClient(name: String, email: String) async -> Bool {
        let body: [String: String] = email.isEmpty ? ["name": name] : ["name": name, "email": email]
        let success = await send(path: "api/v1/admin/clients", method: "POST", body: body)
        if success { await refresh() }
        return success
    }

    func createKey(label: String, days: Int, clientID: Int?, featureIDs: [Int]) async -> String? {
        var body: [String: Any] = ["label": label, "days": days, "featureIds": featureIDs]
        if let clientID { body["clientId"] = clientID }
        guard let data = try? JSONSerialization.data(withJSONObject: body),
              let result: AdminMutationResponse = await sendDecoded(path: "api/v1/admin/keys", method: "POST", data: data) else { return nil }
        await refresh()
        return result.key
    }

    private func send(path: String, method: String, body: [String: String]) async -> Bool {
        guard let data = try? JSONEncoder().encode(body) else { return false }
        return await sendDecoded(path: path, method: method, data: data) as AdminMutationResponse? != nil
    }

    private func sendDecoded<T: Decodable>(path: String, method: String, data: Data) async -> T? {
        guard let token = KeychainStore.read(tokenKey) else { isAuthenticated = false; return nil }
        do {
            var request = URLRequest(url: baseURL.appendingPathComponent(path))
            request.httpMethod = method
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = data
            let (responseData, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else { return nil }
            if http.statusCode == 401 { logout(); return nil }
            if !(200..<300).contains(http.statusCode) {
                let error = (try? JSONDecoder().decode(AdminMutationResponse.self, from: responseData))?.error
                message = error ?? "Operação ADMIN não concluída."
                return nil
            }
            return try JSONDecoder().decode(T.self, from: responseData)
        } catch {
            message = "Erro de comunicação com o servidor."
            return nil
        }
    }
}

private enum KeychainStore {
    static func save(_ value: String, for key: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key]
        SecItemDelete(query as CFDictionary)
        var insert = query
        insert[kSecValueData as String] = data
        SecItemAdd(insert as CFDictionary, nil)
    }

    static func read(_ key: String) -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete(_ key: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrAccount as String: key]
        SecItemDelete(query as CFDictionary)
    }
}
