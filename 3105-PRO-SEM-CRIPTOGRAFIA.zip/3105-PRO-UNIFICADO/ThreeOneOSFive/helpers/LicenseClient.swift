import Foundation
import Combine
import UIKit

struct LicenseFeature: Codable, Identifiable {
    let id: String
    let name: String
    let description: String
}

struct LicenseResponse: Codable {
    let valid: Bool
    let keyId: String?
    let name: String?
    let expiresAt: String?
    let features: [LicenseFeature]?
    let error: String?
}

@MainActor
final class LicenseClient: ObservableObject {
    @Published private(set) var license: LicenseResponse?
    @Published private(set) var enabledFeatureIDs: Set<String> = []
    @Published private(set) var isLoading = false
    @Published var message = ""

    private let baseURL: URL
    private let keyStore = "3105.pro.license.key"
    private let deviceStore = "3105.pro.device.id"
    private let enabledFeaturesStore = "3105.pro.enabled.features"

    init(baseURL: URL = URL(string: "https://allanadmin-aenlcvc2.manus.space")!) {
        self.baseURL = baseURL
    }

    var deviceID: String {
        if let saved = UserDefaults.standard.string(forKey: deviceStore) { return saved }
        let value = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        UserDefaults.standard.set(value, forKey: deviceStore)
        return value
    }

    var savedKey: String? { UserDefaults.standard.string(forKey: keyStore) }
    var availableFeatures: [LicenseFeature] { license?.features ?? [] }

    func isFeatureEnabled(_ featureID: String) -> Bool {
        enabledFeatureIDs.contains(featureID)
    }

    func setFeatureEnabled(_ featureID: String, enabled: Bool) {
        guard availableFeatures.contains(where: { $0.id == featureID }) else { return }
        if enabled {
            enabledFeatureIDs.insert(featureID)
        } else {
            enabledFeatureIDs.remove(featureID)
        }
        persistEnabledFeatures()
    }

    func activate(key: String) async {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { message = "Digite uma KEY."; return }
        isLoading = true
        defer { isLoading = false }

        do {
            var request = URLRequest(url: baseURL.appendingPathComponent("api/v1/client/activate"))
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.timeoutInterval = 20
            request.httpBody = try JSONEncoder().encode([
                "key": normalized,
                "deviceId": deviceID,
                "model": UIDevice.current.model
            ])

            let (data, response) = try await URLSession.shared.data(for: request)
            let result = try JSONDecoder().decode(LicenseResponse.self, from: data)
            guard (response as? HTTPURLResponse)?.statusCode == 200, result.valid else {
                message = result.error ?? "KEY recusada pelo servidor"
                license = nil
                enabledFeatureIDs = []
                return
            }

            license = result
            restoreEnabledFeatures(for: result.features ?? [])
            UserDefaults.standard.set(normalized, forKey: keyStore)
            message = "KEY ativada."
        } catch {
            message = "Não foi possível consultar o servidor: \(error.localizedDescription)"
        }
    }

    func deactivate() {
        license = nil
        enabledFeatureIDs = []
        UserDefaults.standard.removeObject(forKey: keyStore)
        UserDefaults.standard.removeObject(forKey: enabledFeaturesStore)
        message = "KEY removida deste aplicativo."
    }

    private func restoreEnabledFeatures(for features: [LicenseFeature]) {
        let allowed = Set(features.map(\.id))
        if let saved = UserDefaults.standard.array(forKey: enabledFeaturesStore) as? [String] {
            enabledFeatureIDs = Set(saved).intersection(allowed)
        } else {
            enabledFeatureIDs = allowed
        }
    }

    private func persistEnabledFeatures() {
        UserDefaults.standard.set(Array(enabledFeatureIDs).sorted(), forKey: enabledFeaturesStore)
    }
}
