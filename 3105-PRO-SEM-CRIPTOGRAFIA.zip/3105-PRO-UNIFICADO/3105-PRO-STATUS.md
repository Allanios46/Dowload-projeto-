# 3105-PRO — Estado da entrega unificada

## Um único aplicativo iOS

O projeto agora possui somente o target `3105` e gera uma única IPA chamada **Allan IOS EXTERNAL**.

A mesma IPA possui dois fluxos:

- **CLIENTE:** insere uma KEY de cliente, vincula o primeiro dispositivo e recebe somente as funções liberadas.
- **ADMIN:** acessa `Acesso ADMIN` na tela inicial, valida a KEY ADMIN no servidor e abre o console para criar funções, clientes e KEYs.

Não existe mais um target ou uma IPA ADMIN separada.

## Segurança

A KEY ADMIN não é gravada dentro da IPA. A validação ocorre em `POST /api/v1/admin/login` no servidor HTTPS publicado. O token de sessão é armazenado no Keychain e usado apenas nas chamadas ADMIN. As KEYs de clientes são armazenadas no servidor somente como hash.

## Compilação

O arquivo `build_ipa.sh` compila somente o target `3105`. O workflow `.github/workflows/ios-build.yml` executa o mesmo processo em um runner macOS do GitHub e publica `Allan-IOS-EXTERNAL.ipa` como artefato.

A compilação pública gera uma IPA sem assinatura. Para instalar em um iPhone real, configure assinatura Apple e provisioning profile no seu próprio ambiente ou workflow.

## Servidor

A API central publicada em `https://allanadmin-aenlcvc2.manus.space` fornece ativação CLIENTE, autenticação ADMIN, criação de funções, clientes e KEYs com validade e permissões. O servidor continua sendo necessário para controlar licenças, mesmo quando o uso administrativo é feito pela IPA.

Os códigos originais do 3105 foram preservados; a camada ADMIN/CLIENTE foi adicionada ao redor do projeto existente.
