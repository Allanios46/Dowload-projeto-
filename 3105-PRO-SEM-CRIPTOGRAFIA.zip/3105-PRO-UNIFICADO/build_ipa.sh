#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$ROOT_DIR/ThreeOneOSFive.xcodeproj"
BUILD_DIR="${BUILD_DIR:-$ROOT_DIR/build}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/dist}"
IPA_NAME="${IPA_NAME:-Allan-IOS-EXTERNAL.ipa}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Este script precisa ser executado em macOS com Xcode instalado."
  exit 2
fi

if [[ ! -d "$PROJECT" ]]; then
  echo "ERRO: Projeto Xcode não encontrado: $PROJECT"
  exit 1
fi

rm -rf "$BUILD_DIR" "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

echo "Identificando schemes do projeto..."
LIST_OUTPUT="$(xcodebuild -list -project "$PROJECT")"
printf '%s\n' "$LIST_OUTPUT"

SCHEME="$(printf '%s\n' "$LIST_OUTPUT" |
  sed -n '/Schemes:/,$p' |
  grep -E '^[[:space:]]+[A-Za-z0-9_.-]+[[:space:]]*$' |
  head -n 1 |
  xargs || true)"

if [[ -z "$SCHEME" ]]; then
  echo "ERRO: Nenhum scheme encontrado no projeto."
  echo "Confira a seção Schemes exibida acima."
  exit 1
fi

echo "Scheme selecionado: $SCHEME"
echo "Compilando..."

xcodebuild \
  -project "$PROJECT" \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$BUILD_DIR" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  build

APP_PATH="$(find "$BUILD_DIR/Build/Products" -type d -name '*.app' -print -quit)"

if [[ -z "$APP_PATH" || ! -d "$APP_PATH" ]]; then
  echo "ERRO: Nenhum aplicativo .app foi gerado."
  exit 1
fi

mkdir -p "$OUTPUT_DIR/Payload"
cp -R "$APP_PATH" "$OUTPUT_DIR/Payload/"

(
  cd "$OUTPUT_DIR"
  zip -qry "$IPA_NAME" Payload
)

rm -rf "$OUTPUT_DIR/Payload"
echo "IPA gerada: $OUTPUT_DIR/$IPA_NAME"
echo "ATENÇÃO: esta IPA é empacotada sem assinatura; a instalação pode exigir assinatura válida."
