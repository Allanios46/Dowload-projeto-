#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="$ROOT_DIR/ThreeOneOSFive.xcodeproj"
BUILD_DIR="${BUILD_DIR:-$ROOT_DIR/build}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/dist}"
IPA_NAME="${IPA_NAME:-Allan-IOS-EXTERNAL.ipa}"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Este script precisa ser executado em macOS com Xcode instalado."
  exit 2
fi

rm -rf "$BUILD_DIR" "$OUTPUT_DIR"
mkdir -p "$OUTPUT_DIR"

echo "Compilando o target único 3105..."
xcodebuild \
  -project "$PROJECT" \
  -target 3105 \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath "$BUILD_DIR" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  DEVELOPMENT_TEAM="" \
  build

APP_PATH="$BUILD_DIR/Build/Products/Release-iphoneos/3105.app"
if [[ ! -d "$APP_PATH" ]]; then
  APP_PATH="$(find "$BUILD_DIR/Build/Products" -type d -name '3105.app' -print -quit)"
fi
if [[ -z "${APP_PATH:-}" || ! -d "$APP_PATH" ]]; then
  echo "Erro: 3105.app não foi gerado."
  exit 1
fi

mkdir -p "$OUTPUT_DIR/Payload"
cp -R "$APP_PATH" "$OUTPUT_DIR/Payload/"
(cd "$OUTPUT_DIR" && zip -qry "$IPA_NAME" Payload)
rm -rf "$OUTPUT_DIR/Payload"

echo "IPA gerada: $OUTPUT_DIR/$IPA_NAME"
