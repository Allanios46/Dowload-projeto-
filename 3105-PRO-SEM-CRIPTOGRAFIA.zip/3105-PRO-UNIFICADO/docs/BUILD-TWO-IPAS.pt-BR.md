# Gerar as duas IPAs

O projeto Xcode agora possui dois targets separados:

- `3105`: IPA CLIENTE, com o nome `Allan IOS EXTERNAL`.
- `3105 ADMIN`: IPA ADMIN, com o nome `Allan IOS EXTERNAL ADMIN` e bundle identifier `com.allanios46.3105pro.admin`.

No Xcode, selecione o esquema `3105` para arquivar o CLIENTE e o esquema `3105 ADMIN` para arquivar o ADMIN. Cada target precisa de assinatura Apple própria ou de uma configuração de assinatura compatível.

A IPA ADMIN usa a mesma API central para login, criação de KEYs e ativação/desativação de funções. Antes de compilar, configure a URL HTTPS do servidor em `Admin/AdminAPI.swift` e substitua a URL de desenvolvimento em `ThreeOneOSFive/helpers/LicenseClient.swift` e `ThreeOneOSFive/views/LicenseGateView.swift`.

A camada ADMIN controla licenças e funções. Ela não altera os arquivos originais de exploit do projeto.
