# Compilar a IPA unificada no GitHub

Este projeto gera **uma única IPA**, com os dois modos no mesmo aplicativo:

- **CLIENTE:** ativa uma KEY de cliente e exibe somente as funções autorizadas.
- **ADMIN:** botão `Acesso ADMIN` na tela inicial; exige a KEY ADMIN validada pelo servidor e abre o painel para criar funções, clientes e KEYs.

## Pelo GitHub Actions

1. Envie todo o conteúdo deste projeto para o seu repositório GitHub.
2. Abra a aba **Actions**.
3. Selecione **Build Allan IOS EXTERNAL**.
4. Toque em **Run workflow** ou faça um push na branch `main`.
5. Quando terminar, abra a execução e baixe o artefato **Allan-IOS-EXTERNAL-IPA**.
6. Dentro do artefato estará `Allan-IOS-EXTERNAL.ipa`.

O workflow usa macOS com Xcode e compila somente o target `3105`. O projeto não possui mais um target separado de ADMIN.

## Pelo terminal do macOS

```bash
chmod +x build_ipa.sh
./build_ipa.sh
```

O arquivo será criado em `dist/Allan-IOS-EXTERNAL.ipa`.

## Assinatura e instalação

O workflow gera uma IPA sem assinatura para permitir a compilação pública. Para instalar em um iPhone real, é necessário assinar com uma conta/certificado e provisioning profile válidos. O GitHub não recebe certificados privados neste projeto; se você usar assinatura automática, configure os segredos e a identidade no seu próprio repositório.

A IPA não contém a KEY ADMIN. A validação é feita pelo endpoint HTTPS publicado, e o token de sessão é guardado no Keychain do dispositivo.
